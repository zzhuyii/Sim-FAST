function Initialize(obj,node)

    % nothing is needed

end
